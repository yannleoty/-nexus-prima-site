# Nexus Prima — deployment package

This package keeps the current Nexus Prima website and fixes the three planetary images.

## Important

Upload the **contents of this folder** to the root of the GitHub repository connected to Vercel. Do not upload the ZIP itself into the repository.

All files are intentionally kept at the same level. The website now loads:

- `planet-earth.webp`
- `planet-moon.webp`
- `planet-mars.webp`

No `assets` folder is required, which avoids the broken-image path problem.

After uploading, wait for the Vercel deployment to finish, then refresh the website. On iPhone, close the tab and reopen it if Safari still shows a cached version.
